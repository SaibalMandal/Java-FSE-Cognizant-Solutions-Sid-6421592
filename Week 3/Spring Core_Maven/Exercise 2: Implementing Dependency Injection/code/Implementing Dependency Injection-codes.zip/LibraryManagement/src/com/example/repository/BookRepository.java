package com.example.repository;

public class BookRepository {
    public void saveBook(String book) {
        System.out.println("Saving book: " + book);
    }
}
