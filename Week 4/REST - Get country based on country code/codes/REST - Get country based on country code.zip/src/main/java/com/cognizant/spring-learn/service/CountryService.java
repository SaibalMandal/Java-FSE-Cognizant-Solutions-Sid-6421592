package com.cognizant.spring-learn.service;

import com.cognizant.spring-learn.model.Country;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;
import org.springframework.core.io.ClassPathResource;

import javax.xml.parsers.DocumentBuilderFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.w3c.dom.*;

@Service
public class CountryService {

    private List<Country> countries = new ArrayList<>();

    @PostConstruct
    public void init() {
        try {
            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder()
                .parse(new ClassPathResource("country.xml").getInputStream());

            NodeList nodes = doc.getElementsByTagName("country");
            for (int i = 0; i < nodes.getLength(); i++) {
                Element element = (Element) nodes.item(i);
                String code = element.getElementsByTagName("code").item(0).getTextContent();
                String name = element.getElementsByTagName("name").item(0).getTextContent();
                countries.add(new Country(code, name));
            }
        } catch (Exception e) {
            throw new RuntimeException("Error loading country.xml", e);
        }
    }

    public Country getCountry(String code) {
        Optional<Country> country = countries.stream()
            .filter(c -> c.getCode().equalsIgnoreCase(code))
            .findFirst();
        return country.orElseThrow(() -> new RuntimeException("Country not found"));
    }
}