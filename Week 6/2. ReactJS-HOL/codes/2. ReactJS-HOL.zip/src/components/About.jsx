import React from 'react';

const About = () => (
  <div className="bg-white dark:bg-gray-800 shadow-lg rounded-xl p-6 mb-6">
    <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">About</h2>
    <p className="text-gray-700 dark:text-gray-300">
      Welcome to the About page of the Student Management Portal
    </p>
  </div>
);

export default About;
