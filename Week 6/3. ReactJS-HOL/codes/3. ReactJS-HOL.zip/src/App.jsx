import React from 'react';

// Main App Component
// This component serves as the entry point for our application.
// It sets up the main layout and renders the list of student score cards.
export default function App() {
  // An array of student data to be displayed.
  // This makes it easy to add or remove students without changing the component logic.
  const students = [
    { name: "Stephen", school: "St. Anns School", total: 345, goal: 500 },
    { name: "Mary", school: "Greenwood High", total: 450, goal: 500 },
    { name: "John", school: "Oakridge International", total: 290, goal: 500 },
  ];

  return (
    <div className="bg-slate-100 min-h-screen font-sans p-4 sm:p-8">
      <div className="max-w-4xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-4xl font-bold text-slate-800">Student Management Portal</h1>
          <p className="text-slate-600 mt-2">Displaying student scores and results.</p>
        </header>

        <main className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* We map over the students array to render a CalculateScore component for each student. */}
          {/* The 'key' prop is important for React to efficiently update the list. */}
          {students.map((student, index) => (
            <CalculateScore
              key={index}
              name={student.name}
              school={student.school}
              total={student.total}
              goal={student.goal}
            />
          ))}
        </main>
      </div>
    </div>
  );
}

// CalculateScore Component
// This is a functional component that calculates and displays a student's score card.
// It is reusable and receives student data via props.
const CalculateScore = ({ name, school, total, goal }) => {
  // Calculate the percentage based on the total score and the goal.
  const percentage = (total / goal) * 100;

  // Determine the result text and color based on the percentage.
  // A score of 70% or higher is considered a pass.
  const resultInfo = percentage >= 70 
    ? { text: `You have passed the exam with ${percentage.toFixed(2)}%.`, color: 'text-green-600' }
    : { text: `You have failed the exam with ${percentage.toFixed(2)}%.`, color: 'text-red-600' };

  return (
    // The main container for the score card with styling.
    <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-500 transition-transform transform hover:scale-105">
      <header className="mb-4">
        <h2 className="text-2xl font-bold text-blue-600">{school}</h2>
      </header>

      {/* Container for the student's details. */}
      <div className="space-y-2 text-slate-700">
        <p><span className="font-semibold">Name:</span> {name}</p>
        <p><span className="font-semibold">Total Score:</span> {total}</p>
        <p><span className="font-semibold">Maximum Score:</span> {goal}</p>
        <p><span className="font-semibold">Percentage:</span> {percentage.toFixed(2)}%</p>
      </div>

      <hr className="my-4" />

      {/* The result message, with color dynamically applied based on pass/fail status. */}
      <footer className={`text-lg font-semibold ${resultInfo.color}`}>
        <p>{resultInfo.text}</p>
      </footer>
    </div>
  );
};