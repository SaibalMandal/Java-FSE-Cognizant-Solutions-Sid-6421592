import React, { useState, useEffect } from 'react';

class Post {
    constructor(id, title, body) {
        this.id = id;
        this.title = title;
        this.body = body;
    }
}

class ErrorBoundary extends React.Component {
    constructor(props) {
        super(props);
        this.state = { hasError: false, error: null, errorInfo: null };
    }

    static getDerivedStateFromError(error) {
        return { hasError: true };
    }

    componentDidCatch(error, errorInfo) {
        console.error("Uncaught error:", error, errorInfo);
        this.setState({ error: error, errorInfo: errorInfo });
    }

    render() {
        if (this.state.hasError) {
            return (
                <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-lg" role="alert">
                    <h2 className="font-bold text-lg mb-2">Something went wrong.</h2>
                    <p>We're sorry, but an unexpected error occurred. Please try refreshing the page.</p>
                    <details className="mt-4 text-sm whitespace-pre-wrap">
                      <summary>Error Details</summary>
                      {this.state.error && this.state.error.toString()}
                      <br />
                      {this.state.errorInfo && this.state.errorInfo.componentStack}
                    </details>
                </div>
            );
        }

        return this.props.children;
    }
}

const Posts = () => {
    const [posts, setPosts] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const loadPosts = async () => {
            try {
                const response = await fetch('https://jsonplaceholder.typicode.com/posts');
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                const data = await response.json();
                setPosts(data);
            } catch (e) {
                console.error("Failed to fetch posts:", e);
                setError(e.message);
            } finally {
                setIsLoading(false);
            }
        };

        loadPosts();
    }, []);

    if (isLoading) {
        return (
            <div className="text-center p-10">
                <p className="text-lg text-gray-500">Loading posts...</p>
            </div>
        );
    }

    if (error) {
        return (
             <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg relative" role="alert">
                <strong className="font-bold">Error:</strong>
                <span className="block sm:inline"> Failed to load posts. {error}</span>
            </div>
        )
    }

    return (
        <div className="space-y-6">
            {posts.map(post => (
                <div key={post.id} className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300">
                    <h2 className="text-2xl font-bold text-gray-800 mb-2 capitalize">{post.title}</h2>
                    <p className="text-gray-600">{post.body}</p>
                </div>
            ))}
        </div>
    );
};

export default function App() {
    return (
        <div className="bg-gray-50 min-h-screen font-sans">
            <div className="container mx-auto p-4 sm:p-6 lg:p-8">
                <header className="text-center mb-8">
                    <h1 className="text-4xl sm:text-5xl font-extrabold text-gray-900 tracking-tight">
                        My Blog Feed
                    </h1>
                    <p className="mt-2 text-lg text-gray-500">
                        Latest posts fetched from a remote API.
                    </p>
                </header>
                <main>
                    <ErrorBoundary>
                        <Posts />
                    </ErrorBoundary>
                </main>
                 <footer className="text-center mt-12 text-gray-400 text-sm">
                    <p>Lab completed using React and Tailwind CSS.</p>
                </footer>
            </div>
        </div>
    );
}
