import React from 'react';
import CohortDetails from './components/CohortDetails';

export default function App() {
  const cohortsData = [
    {
      id: 1,
      name: 'INTADMDF10',
      program: '.NET FSD',
      startDate: '22-Feb-2022',
      status: 'Scheduled',
      coach: 'Aathma',
      trainer: 'Jojo Jose',
    },
    {
      id: 2,
      name: 'ADM21JF014',
      program: 'Java FSD',
      startDate: '10-Sep-2021',
      status: 'Ongoing',
      coach: 'Apoorv',
      trainer: 'Elisa Smith',
    },
    {
      id: 3,
      name: 'CDBJF21025',
      program: 'Java FSD',
      startDate: '24-Dec-2021',
      status: 'Ongoing',
      coach: 'Aathma',
      trainer: 'John Doe',
    },
  ];

  return (
    <div style={{ padding: '20px', backgroundColor: '#f4f7f6', minHeight: '100vh' }}>
      <h1 style={{ fontFamily: 'sans-serif', fontWeight: 'bold', marginBottom: '20px' }}>
        Cohorts Details
      </h1>
      <div style={{ textAlign: 'center' }}>
        {cohortsData.map((cohort) => (
          <CohortDetails key={cohort.id} data={cohort} />
        ))}
      </div>
    </div>
  );
}