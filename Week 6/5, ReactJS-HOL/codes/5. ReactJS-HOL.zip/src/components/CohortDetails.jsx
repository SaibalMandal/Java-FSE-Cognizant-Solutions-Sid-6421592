import React from 'react';
import styles from './CohortDetails.module.css';

const CohortDetails = ({ data }) => {
  const headerStyle = {
    color: data.status === 'Ongoing' ? 'green' : 'blue',
    fontSize: '1.1em',
    marginBottom: '15px',
  };

  return (
    <div className={styles.box}>
      <h3 style={headerStyle}>
        {data.name} - {data.program}
      </h3>
      <dl>
        <dt>Started On</dt>
        <dd>{data.startDate}</dd>

        <dt>Current Status</dt>
        <dd>{data.status}</dd>

        <dt>Coach</dt>
        <dd>{data.coach}</dd>

        <dt>Trainer</dt>
        <dd>{data.trainer}</dd>
      </dl>
    </div>
  );
};

export default CohortDetails;