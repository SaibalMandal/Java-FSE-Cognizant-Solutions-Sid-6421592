import React, { useState } from 'react';

export default function App() {
  return (
    <div className="bg-slate-100 min-h-screen font-sans">
      <header className="bg-white shadow">
        <div className="max-w-4xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold leading-tight text-gray-900">
            React Event Handling Examples
          </h1>
        </div>
      </header>
      <main className="max-w-4xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="space-y-8">
            <Counter />
            <Welcome />
            <SyntheticEventDemo />
            <CurrencyConvertor />
          </div>
        </div>
      </main>
    </div>
  );
}

function Counter() {
  const [count, setCount] = useState(0);
  const [message, setMessage] = useState('');

  const increment = () => setCount(prevCount => prevCount + 1);
  const decrement = () => setCount(prevCount => prevCount - 1);
  
  const sayHello = () => {
    setMessage('Hello! You clicked the increment button.');
    setTimeout(() => setMessage(''), 3000);
  };

  const handleIncrementClick = () => {
    increment();
    sayHello();
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-semibold mb-4 text-gray-800">Counter</h2>
      <div className="flex items-center justify-center space-x-4">
        <button onClick={decrement} className="px-6 py-2 bg-red-500 text-white font-semibold rounded-lg shadow-md hover:bg-red-600 transition">
          Decrement
        </button>
        <span className="text-4xl font-bold text-gray-900 w-20 text-center">{count}</span>
        <button onClick={handleIncrementClick} className="px-6 py-2 bg-green-500 text-white font-semibold rounded-lg shadow-md hover:bg-green-600 transition">
          Increment
        </button>
      </div>
      {message && <p className="text-center mt-4 text-green-600 font-medium">{message}</p>}
    </div>
  );
}

function Welcome() {
  const [welcomeMessage, setWelcomeMessage] = useState('');
  const showMessage = (msg) => {
    setWelcomeMessage(`The message is: "${msg}"`);
    setTimeout(() => setWelcomeMessage(''), 3000);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md text-center">
      <h2 className="text-2xl font-semibold mb-4 text-gray-800">Argument Passing Demo</h2>
      <button onClick={() => showMessage('welcome')} className="px-6 py-2 bg-blue-500 text-white font-semibold rounded-lg shadow-md hover:bg-blue-600 transition">
        Say Welcome
      </button>
      {welcomeMessage && <p className="mt-4 text-blue-600 font-medium">{welcomeMessage}</p>}
    </div>
  );
}

function SyntheticEventDemo() {
  const [clickMessage, setClickMessage] = useState('');
  const handlePress = (event) => {
    console.log('SyntheticEvent object:', event);
    setClickMessage('I was clicked! (Check console for SyntheticEvent object)');
    setTimeout(() => setClickMessage(''), 4000);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md text-center">
      <h2 className="text-2xl font-semibold mb-4 text-gray-800">Synthetic Event Demo</h2>
      <button onClick={handlePress} className="px-6 py-2 bg-purple-500 text-white font-semibold rounded-lg shadow-md hover:bg-purple-600 transition">
        Invoke Synthetic Event
      </button>
      {clickMessage && <p className="mt-4 text-purple-600 font-medium">{clickMessage}</p>}
    </div>
  );
}

function CurrencyConvertor() {
  const [inr, setInr] = useState('');
  const [eur, setEur] = useState(null);
  const INR_TO_EUR_RATE = 0.011;

  const handleInputChange = (event) => {
    const value = event.target.value;
    if (/^\d*\.?\d*$/.test(value)) {
      setInr(value);
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (inr > 0) {
      const convertedAmount = (parseFloat(inr) * INR_TO_EUR_RATE).toFixed(2);
      setEur(convertedAmount);
    } else {
      setEur(null);
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-semibold mb-4 text-gray-800">Currency Convertor</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="inr-input" className="block text-sm font-medium text-gray-700">Indian Rupees (INR)</label>
          <div className="mt-1">
            <input type="text" id="inr-input" value={inr} onChange={handleInputChange} placeholder="e.g., 1000"
              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
          </div>
        </div>
        <div className="text-center">
          <button type="submit" className="w-full sm:w-auto px-6 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition">
            Convert
          </button>
        </div>
      </form>
      {eur !== null && (
        <div className="mt-6 p-4 bg-gray-50 rounded-lg text-center">
          <p className="text-lg font-medium text-gray-900">
            <span className="font-bold">{inr}</span> INR is equal to <span className="font-bold text-indigo-600">{eur}</span> EUR
          </p>
        </div>
      )}
    </div>
  );
}