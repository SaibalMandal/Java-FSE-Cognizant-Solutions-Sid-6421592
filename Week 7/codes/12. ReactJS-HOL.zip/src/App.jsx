import React, { useState } from 'react';

function UserGreeting() {
  return (
    <div className="text-center">
      <h1 className="text-4xl font-bold text-gray-800 mb-2">Welcome back</h1>
      <p className="text-lg text-gray-600">You can now book your flight tickets.</p>
    </div>
  );
}

function GuestGreeting() {
  return (
    <div className="text-center">
      <h1 className="text-4xl font-bold text-gray-800 mb-2">Please sign up.</h1>
      <p className="text-lg text-gray-600">Browse our flight details below.</p>
    </div>
  );
}

function Greeting(props) {
  const isLoggedIn = props.isLoggedIn;
  return isLoggedIn ? <UserGreeting /> : <GuestGreeting />;
}

function LoginButton(props) {
  return (
    <button 
      onClick={props.onClick}
      className="px-6 py-2 bg-blue-500 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-opacity-75 transition duration-300 ease-in-out"
    >
      Login
    </button>
  );
}

function LogoutButton(props) {
  return (
    <button 
      onClick={props.onClick}
      className="px-6 py-2 bg-red-500 text-white font-semibold rounded-lg shadow-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-400 focus:ring-opacity-75 transition duration-300 ease-in-out"
    >
      Logout
    </button>
  );
}

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLoginClick = () => setIsLoggedIn(true);
  const handleLogoutClick = () => setIsLoggedIn(false);

  const button = isLoggedIn ? (
    <LogoutButton onClick={handleLogoutClick} />
  ) : (
    <LoginButton onClick={handleLoginClick} />
  );

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center font-sans">
      <div className="p-8 bg-white rounded-xl shadow-lg space-y-6">
        <Greeting isLoggedIn={isLoggedIn} />
        <div className="flex justify-center">{button}</div>
      </div>
    </div>
  );
}