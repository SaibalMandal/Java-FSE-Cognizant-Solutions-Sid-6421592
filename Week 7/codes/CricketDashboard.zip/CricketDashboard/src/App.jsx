import React, { useState } from 'react';

export default function App() {
  const [showListOfPlayers, setShowListOfPlayers] = useState(true);

  return (
    <div className="bg-gray-100 min-h-screen font-sans">
      <div className="container mx-auto p-4 sm:p-6 md:p-8">
        <header className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-extrabold text-gray-800 tracking-tight">
            Cricket Players Dashboard
          </h1>
          <p className="text-lg text-gray-600 mt-2">
            Exploring ES6 features with React
          </p>
        </header>

        <div className="flex justify-center mb-8">
          <button
            onClick={() => setShowListOfPlayers(!showListOfPlayers)}
            className="px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-opacity-75 transition-all duration-300 ease-in-out transform hover:scale-105"
          >
            Toggle View
          </button>
        </div>

        <main className="bg-white p-6 rounded-xl shadow-lg">
          {showListOfPlayers ? <ListOfPlayers /> : <IndianPlayers />}
        </main>
      </div>
    </div>
  );
}

function ListOfPlayers() {
  const players = [
    { name: 'Jack', score: 50 },
    { name: 'Michael', score: 70 },
    { name: 'John', score: 40 },
    { name: 'Ann', score: 61 },
    { name: 'Elisabeth', score: 61 },
    { name: 'Sachin', score: 95 },
    { name: 'Dhoni', score: 100 },
    { name: 'Virat', score: 84 },
    { name: 'Jadeja', score: 64 },
    { name: 'Raina', score: 75 },
    { name: 'Rohit', score: 80 },
  ];
  const playersBelow70 = players.filter(player => player.score < 70);

  return (
    <div className="space-y-8">
      <section>
        <h2 className="text-2xl font-bold text-gray-700 mb-4 border-b-2 border-blue-200 pb-2">
          Complete List of Players
        </h2>
        <ul className="list-disc list-inside space-y-2 text-gray-800">
          {players.map((player, index) => (
            <li key={index} className="p-2 rounded-md hover:bg-gray-50">
              Mr. {player.name} - <span className="font-semibold text-blue-600">{player.score}</span>
            </li>
          ))}
        </ul>
      </section>

      <div className="border-t border-gray-200"></div>

      <section>
        <h2 className="text-2xl font-bold text-gray-700 mb-4 border-b-2 border-red-200 pb-2">
          Players with Scores Less than 70
        </h2>
        <ul className="list-disc list-inside space-y-2 text-gray-800">
          {playersBelow70.map((player, index) => (
            <li key={index} className="p-2 rounded-md hover:bg-gray-50">
              Mr. {player.name} - <span className="font-semibold text-red-600">{player.score}</span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

function IndianPlayers() {
  const indianTeam = ['Sachin1', 'Dhoni2', 'Virat3', 'Rohit4', 'Yuvraj5', 'Raina6'];
  const T20Players = ['First Player', 'Second Player', 'Third Player'];
  const RanjiTrophyPlayers = ['Fourth Player', 'Fifth Player', 'Sixth Player'];
  const mergedIndianPlayers = [...T20Players, ...RanjiTrophyPlayers];

  return (
    <div className="space-y-8">
      <section>
        <h2 className="text-2xl font-bold text-gray-700 mb-4 border-b-2 border-green-200 pb-2">
          Team Composition (Destructuring)
        </h2>
        <div className="grid md:grid-cols-2 gap-8">
          <OddPlayers team={indianTeam} />
          <EvenPlayers team={indianTeam} />
        </div>
      </section>

      <div className="border-t border-gray-200"></div>

      <section>
        <h2 className="text-2xl font-bold text-gray-700 mb-4 border-b-2 border-purple-200 pb-2">
          Merged List of Indian Players
        </h2>
        <ul className="list-disc list-inside space-y-2 text-gray-800">
          {mergedIndianPlayers.map((player, index) => (
            <li key={index} className="p-2 rounded-md hover:bg-gray-50">
              Mr. {player}
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

function OddPlayers({ team }) {
  const [first, , third, , fifth] = team;
  return (
    <div>
      <h3 className="text-xl font-semibold text-gray-600 mb-3">Odd Players</h3>
      <ul className="list-decimal list-inside space-y-2 text-gray-800">
        <li className="p-2 rounded-md hover:bg-green-50">First: {first}</li>
        <li className="p-2 rounded-md hover:bg-green-50">Third: {third}</li>
        <li className="p-2 rounded-md hover:bg-green-50">Fifth: {fifth}</li>
      </ul>
    </div>
  );
}

function EvenPlayers({ team }) {
  const [, second, , fourth, , sixth] = team;
  return (
    <div>
      <h3 className="text-xl font-semibold text-gray-600 mb-3">Even Players</h3>
      <ul className="list-decimal list-inside space-y-2 text-gray-800">
        <li className="p-2 rounded-md hover:bg-yellow-50">Second: {second}</li>
        <li className="p-2 rounded-md hover:bg-yellow-50">Fourth: {fourth}</li>
        <li className="p-2 rounded-md hover:bg-yellow-50">Sixth: {sixth}</li>
      </ul>
    </div>
  );
}
