import React from 'react';

// Main App component
export default function App() {
  // Array of office space objects
  const officeSpaces = [
    {
      name: 'DBS',
      rent: 50000,
      address: 'Chennai',
      imageUrl: 'https://placehold.co/600x400/EEE/31343C?text=Modern+Office',
    },
    {
      name: 'The Executive Centre',
      rent: 75000,
      address: 'Mumbai',
      imageUrl: 'https://placehold.co/600x400/DDD/31343C?text=Luxury+Suite',
    },
    {
      name: 'WeWork',
      rent: 58000,
      address: 'Bangalore',
      imageUrl: 'https://placehold.co/600x400/CCC/31343C?text=Collaborative+Space',
    },
    {
      name: 'Regus',
      rent: 90000,
      address: 'Delhi',
      imageUrl: 'https://placehold.co/600x400/BBB/31343C?text=Premium+Office',
    },
  ];

  // Component to render a single office space
  const OfficeSpace = ({ item }) => {
    // Determine the color for the rent based on its value
    const rentStyle = {
      color: item.rent <= 60000 ? 'red' : 'green',
      fontWeight: 'bold',
    };

    return (
      <div className="bg-white shadow-lg rounded-lg p-6 mb-8 w-full max-w-md">
        {/* Office Image */}
        <img 
          src={item.imageUrl} 
          alt={`Office space at ${item.name}`} 
          className="w-full h-48 object-cover rounded-md mb-4"
          onError={(e) => { e.target.onerror = null; e.target.src='https://placehold.co/600x400/EEE/31343C?text=Image+Not+Found'; }}
        />
        {/* Office Details */}
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Name: {item.name}</h2>
        <p className="text-lg text-gray-600 mb-2">
          Rent: <span style={rentStyle}>Rs. {item.rent.toLocaleString()}</span>
        </p>
        <p className="text-lg text-gray-600">Address: {item.address}</p>
      </div>
    );
  };

  return (
    <div className="bg-gray-100 min-h-screen font-sans">
      <div className="container mx-auto p-4 sm:p-6 lg:p-8">
        {/* Main Heading */}
        <header className="text-center mb-10">
          <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900">
            Office Space, at Affordable Range
          </h1>
        </header>

        {/* Grid for Office Spaces */}
        <main className="flex flex-wrap justify-center gap-8">
          {/* Loop through the officeSpaces array and render each one */}
          {officeSpaces.map((space, index) => (
            <OfficeSpace key={index} item={space} />
          ))}
        </main>
      </div>
    </div>
  );
}
